import java.util.Scanner; //input
public class Main {
	static Scanner input = new Scanner(System.in); //required for input function
  public static void main(String[] args) {
    //input.nextDouble(); // double input
	//input.nextLine(); //string input
	//input.nextInt(); //integer input
	System.out.print(letterOrWordSearch("This is Avery."));


	
	


  }
  
  public static int letterOrWordSearch(String input) {
	  int count = 0;
	  String find  = " "; //What word they want to find
	  int findLength = find.length();
	  for (int i = 0; i<input.length() - findLength + 1;i++) {
		  String check = "";
		  check=input.substring(i,i+findLength);
		  if (check.equals(find)) {
			  count = i;
			  i = input.length();
		  }
	  }
	  return count;
  }
}
